# Data Science Ecosystem

This repository contains the final assignment notebook for the Data Science Tools and Ecosystem project.

## Contents
- `DataScienceEcosystem.ipynb`: Jupyter Notebook with exercises
- Screenshots (to be added by you for peer review)

## Instructions
1. Open the notebook in Jupyter Notebook, JupyterLite, or Anaconda.
2. Run all cells to see outputs.
3. Take required screenshots as per the assignment instructions.
4. Upload screenshots into this repository (optional).

## Author
Your Name
